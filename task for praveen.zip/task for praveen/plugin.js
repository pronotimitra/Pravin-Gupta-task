
class Dashboard {
  constructor(apiUrl) {
    this.apiUrl = apiUrl;
  }

  // Fetch data from API
  async fetchData() {
    try {
      const response = await fetch(this.apiUrl);
      return await response.json();
    } catch (error) {
      console.error("Failed to fetch data:", error);
      return null;
    }
  }

  
  renderCharts(data) {
    const cpuChart = new Chart(document.getElementById("cpuChart"), {
      type: "doughnut",
      data: {
        labels: ["Requests", "Limits", "Unused"],
        datasets: [
          {
            data: data.cpu,
            backgroundColor: ["#36A2EB", "#FFCE56", "#4BC0C0"],
          },
        ],
      },
    });

    const memoryChart = new Chart(document.getElementById("memoryChart"), {
      type: "doughnut",
      data: {
        labels: ["Requests", "Limits", "Unused"],
        datasets: [
          {
            data: data.memory,
            backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
          },
        ],
      },
    });

    const podsChart = new Chart(document.getElementById("podsChart"), {
      type: "doughnut",
      data: {
        labels: ["Allocated", "Unused"],
        datasets: [
          {
            data: data.pods,
            backgroundColor: ["#4BC0C0", "#FF6384"],
          },
        ],
      },
    });
  }

 
  renderTable(pods) {
    const tableBody = document.getElementById("podTable");
    tableBody.innerHTML = ""; 

    pods.forEach((pod) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${pod.name}</td>
        <td>${pod.labels}</td>
        <td>${pod.node}</td>
        <td>${pod.status}</td>
        <td>${pod.cpuUsage}</td>
        <td>${pod.memoryUsage}</td>
        <td>${pod.age}</td>
      `;
      tableBody.appendChild(row);
    });
  }

 
  async init() {
    const data = await this.fetchData();
    if (data) {
      this.renderCharts(data.allocation);
      this.renderTable(data.pods);
    }
  }
}


const dashboard = new Dashboard("http://localhost:5000/getData");
dashboard.init();
