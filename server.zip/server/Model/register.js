const mongoose = require("mongoose");

const RegisterSchema = new mongoose.Schema({
    allocation: {
        cpu: [Number],
        memory: [Number],
        pods: [Number]
    },
    pods: [
        {
            name: { type: String, required: true },
            labels: String,
            node: String,
            status: String,
            cpuUsage: String,
            memoryUsage: String,
            age: String
        }
    ]
});

const Register = mongoose.model("Register", RegisterSchema);

module.exports = Register;
