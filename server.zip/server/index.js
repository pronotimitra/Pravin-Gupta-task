const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;


app.use(cors());
app.use(express.json());

require('./db/config'); 


const Register = require('./Model/register'); 


app.get('/getData', async (req, res) => {
    try {
        const data = await Register.find(); 
        res.json({ 
            allocation: {
                cpu: [1.34, 0.66, 0.4],
                memory: [952, 404, 584],
                pods: [24, 86],
            },
            pods: [
                {
                    name: "Ajay",
                    labels: "manager",
                    node: "worker-node-1",
                    status: "Running",
                    cpuUsage: "10%",
                    memoryUsage: "20%",
                    age: "29",
                },
                {
                    name: "Sandeep",
                    labels: "manager",
                    node: "worker-node-2",
                    status: "Running",
                    cpuUsage: "15%",
                    memoryUsage: "25%",
                    age: "25",
                },
                {
                    name: "Satyam",
                    labels: "manager",
                    node: "worker-node-3",
                    status: "Running",
                    cpuUsage: "15%",
                    memoryUsage: "25%",
                    age: "24",
                },
            ]
        });
    } catch (error) {
        res.status(404).send({ error: error.message });
    }
});




app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
    console.log(`http://localhost:${port}`);
});
